#pip install schedule
import time
from urllib import response
import schedule
import requests
from openapi.weather import DUST as dust

#url = 'http://localhost:3000'

def job():
    #dust value 받아오기
    val = dust.getDustG_API('부림동',serviceKey)
    print(val)
    params = {'dust': val}


    if (val == 'good'):
        response = requests.get('http://localhost:3000/apOFF', params=params)
        #print(response.url) http://localhost:3000/apOFF?dust=good
        print(response.status_code)
        print(response.text)

    elif (val == 'soso'):
        response = requests.get('http://localhost:3000/apON', params=params)
        print(response.status_code)
        print(response.text)

    elif (val == 'bad'):
        response = requests.get('http://localhost:3000/apON', params=params)
        print(response.status_code)
        print(response.text)

    else:
        response = requests.get('http://localhost:3000/apON', params=params)
        print(response.status_code)
        print(response.text)

    #사용자가 수면중이면 apSleepON/OFF


#schedule.every().hour.at(":05").do(job) #openAPI 갱신되는 시간 고려해서 매 시간 05분마다 반복
schedule.every(5).seconds.do(job) #test용 print

while True:
    schedule.run_pending()
    time.sleep(1)

