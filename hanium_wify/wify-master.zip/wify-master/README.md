

서버 실행 
python manage.py runserver
ctrl c 중지


